# Arcade Football 3D — Mobil prototip

## Kurulum
1. Unity Hub'da 3D Core projesi aç.
2. Bu paketteki `Assets` klasörünü projenin `Assets` klasörüne kopyala.
3. Derleme bitince menüden **Arcade Football → Create Mobile Prototype Scene** seç.
4. `Assets/ArcadeFootballMobile.unity` sahnesinde Play'e bas. Mobil joystick, PAS, ŞUT ve SPRINT butonları otomatik oluşturulur.

## PC kontrolleri
- WASD: hareket
- Left Shift: koşu
- Space / sol tık: basılı tutarak şut
- E / sağ tık: pas

## Mobil kontroller
- Sol joystick: hareket
- PASS: pas
- SHOOT: basılı tutarak şut gücü biriktir
- SPRINT: basılı tutarak koş

## Android APK oluşturma
1. Unity Hub > Installs > kullandığın Unity sürümü > Android Build Support, Android SDK & NDK Tools ve OpenJDK bileşenlerini kur.
2. Unity > File > Build Settings (yeni sürümlerde Build Profiles) > Android > Switch Platform.
3. Player Settings'te Package Name belirle, Orientation'ı Landscape Left/Right seç.
4. `Assets/ArcadeFootballMobile.unity` sahnesini Scenes In Build listesine ekle.
5. Build veya Build And Run ile APK oluştur.

## Notlar
- Bu kaynak paketi Unity proje dosyası değil, bir Unity projesinin `Assets` klasörüne kopyalanacak kaynaklardır.
- Unity Editor menüsü sahneyi otomatik kurar; derlenmiş APK bu ortamda üretilmemiştir.
- `PlayerController` PC'de klasik Input Manager kullanır. Player Settings > Active Input Handling'i Both veya Input Manager (Old) yap.
- Düşük poligonlu primitive modeller kullanılmıştır. Özel oyuncu modelleri, animasyonlar, sesler, maç süresi ve daha gelişmiş takım arkadaşları sonraki aşamalarda eklenebilir.
