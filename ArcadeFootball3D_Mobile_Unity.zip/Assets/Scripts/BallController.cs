using UnityEngine;

[RequireComponent(typeof(Rigidbody), typeof(SphereCollider))]
public class BallController : MonoBehaviour
{
    public float dribbleFollowSpeed = 12f;
    public Vector3 dribbleOffset = new Vector3(0f, 0.15f, 1.25f);
    public GameObject Owner { get; private set; }
    Rigidbody body;

    void Awake()
    {
        body = GetComponent<Rigidbody>();
        body.mass = 0.43f;
        body.drag = 0.18f;
        body.angularDrag = 0.08f;
        body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;

        PhysicMaterial mat = new PhysicMaterial("BallPhysics");
        mat.dynamicFriction = 0.35f;
        mat.staticFriction = 0.4f;
        mat.bounciness = 0.45f;
        mat.frictionCombine = PhysicMaterialCombine.Average;
        mat.bounceCombine = PhysicMaterialCombine.Average;
        GetComponent<SphereCollider>().material = mat;
    }

    void FixedUpdate()
    {
        if (Owner == null) return;
        Vector3 target = Owner.transform.position +
                         Owner.transform.TransformDirection(dribbleOffset);
        target.y = Mathf.Max(0.22f, target.y);
        body.MovePosition(Vector3.MoveTowards(body.position, target,
            dribbleFollowSpeed * Time.fixedDeltaTime));
        body.velocity = Vector3.zero;
        body.angularVelocity = Vector3.zero;
    }

    public bool TryTake(GameObject newOwner)
    {
        if (newOwner == null || (Owner != null && Owner != newOwner)) return false;
        Owner = newOwner;
        body.velocity = Vector3.zero;
        body.angularVelocity = Vector3.zero;
        return true;
    }

    public void Kick(Vector3 direction, float power)
    {
        Owner = null;
        body.velocity = Vector3.zero;
        body.angularVelocity = Vector3.zero;
        body.AddForce(direction.normalized * power, ForceMode.Impulse);
    }

    public void ResetBall(Vector3 position)
    {
        Owner = null;
        body.velocity = Vector3.zero;
        body.angularVelocity = Vector3.zero;
        body.position = position;
        body.rotation = Quaternion.identity;
    }
}
