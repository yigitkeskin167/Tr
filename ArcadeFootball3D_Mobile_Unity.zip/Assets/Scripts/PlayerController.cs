using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class PlayerController : MonoBehaviour
{
    public BallController ball;
    public float moveSpeed = 7f;
    public float sprintMultiplier = 1.45f;
    public float turnSpeed = 12f;
    public float controlDistance = 1.8f;
    public float minShotPower = 7f;
    public float maxShotPower = 20f;
    public float shotChargeSeconds = 1.25f;
    public float passPower = 8.5f;
    public string teammateTag = "Player";

    Rigidbody body;
    Vector2 moveInput;
    bool sprint;
    bool charging;
    float charge;

    void Awake()
    {
        body = GetComponent<Rigidbody>();
        body.constraints |= RigidbodyConstraints.FreezeRotationX |
                            RigidbodyConstraints.FreezeRotationZ;
        if (ball == null) ball = FindObjectOfType<BallController>();
    }

    void Update()
    {
        // PC klavye kontrolü; mobilde joystick SetMoveInput kullanır.
        if (!Application.isMobilePlatform)
        {
            moveInput = new Vector2(Input.GetAxisRaw("Horizontal"),
                                    Input.GetAxisRaw("Vertical")).normalized;
            sprint = Input.GetKey(KeyCode.LeftShift);
        }

        bool shootDown = Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0);
        bool shootUp = Input.GetKeyUp(KeyCode.Space) || Input.GetMouseButtonUp(0);
        if (shootDown) BeginShot();
        if (charging) charge = Mathf.Clamp01(charge + Time.deltaTime / shotChargeSeconds);
        if (shootUp && charging) ReleaseShot();

        if (Input.GetKeyDown(KeyCode.E) || Input.GetMouseButtonDown(1)) PassBall();
    }

    void FixedUpdate()
    {
        Vector3 dir = new Vector3(moveInput.x, 0f, moveInput.y);
        Vector3 desired = dir * moveSpeed * (sprint ? sprintMultiplier : 1f);
        body.velocity = new Vector3(desired.x, body.velocity.y, desired.z);

        if (dir.sqrMagnitude > 0.01f)
            body.MoveRotation(Quaternion.Slerp(body.rotation,
                Quaternion.LookRotation(dir), turnSpeed * Time.fixedDeltaTime));

        if (ball != null && ball.Owner == null &&
            Vector3.Distance(transform.position, ball.transform.position) <= controlDistance)
            ball.TryTake(gameObject);
    }

    void BeginShot()
    {
        if (ball == null || ball.Owner != gameObject) return;
        charging = true;
        charge = 0f;
    }

    void ReleaseShot()
    {
        charging = false;
        if (ball == null || ball.Owner != gameObject) return;
        float power = Mathf.Lerp(minShotPower, maxShotPower, charge);
        ball.Kick((transform.forward + Vector3.up * 0.16f).normalized, power);
    }

    public void PassBall()
    {
        if (ball == null || ball.Owner != gameObject) return;
        GameObject nearest = null;
        float best = float.MaxValue;

        foreach (GameObject candidate in GameObject.FindGameObjectsWithTag(teammateTag))
        {
            if (candidate == gameObject || candidate.GetComponent<EnemyAI>() != null) continue;
            float d = (candidate.transform.position - transform.position).sqrMagnitude;
            if (d < best) { best = d; nearest = candidate; }
        }

        Vector3 direction = nearest != null
            ? nearest.transform.position - ball.transform.position
            : transform.forward;
        direction.y = 0.04f;
        ball.Kick(direction.normalized, passPower);
    }

    public void SetMoveInput(Vector2 value) { moveInput = Vector2.ClampMagnitude(value, 1f); }
    public void SetSprint(bool value) { sprint = value; }
    public void MobilePass() { PassBall(); }
    public void MobileShootDown() { BeginShot(); }
    public void MobileShootUp() { ReleaseShot(); }
}
