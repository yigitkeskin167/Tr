using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }
    public BallController ball;
    public Transform kickoffPoint;
    public Transform playerSpawn;
    public Transform enemySpawn;
    public Text scoreText;
    public Text messageText;
    public int playerScore;
    public int enemyScore;
    public float resetDelay = 1.5f;
    bool goalInProgress;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        UpdateUI();
    }

    public void GoalScored(bool playerTeamScored)
    {
        if (goalInProgress) return;
        goalInProgress = true;
        if (playerTeamScored) playerScore++; else enemyScore++;
        UpdateUI();
        if (messageText != null) messageText.text = playerTeamScored ? "GOOOL! MAVİ TAKIM" : "GOL! KIRMIZI TAKIM";
        Invoke(nameof(ResetKickoff), resetDelay);
    }

    void ResetKickoff()
    {
        if (ball != null) ball.ResetBall(kickoffPoint != null ? kickoffPoint.position : Vector3.up * 0.25f);
        ResetActor(GameObject.FindGameObjectWithTag("Player"), playerSpawn);
        EnemyAI enemy = FindObjectOfType<EnemyAI>();
        ResetActor(enemy != null ? enemy.gameObject : null, enemySpawn);
        if (messageText != null) messageText.text = "OYUN DEVAM EDİYOR";
        goalInProgress = false;
    }

    void ResetActor(GameObject actor, Transform spawn)
    {
        if (actor == null || spawn == null) return;
        actor.transform.position = spawn.position;
        Rigidbody rb = actor.GetComponent<Rigidbody>();
        if (rb != null) rb.velocity = Vector3.zero;
    }

    void UpdateUI()
    {
        if (scoreText != null) scoreText.text = "MAVİ  " + playerScore + "  -  " + enemyScore + "  KIRMIZI";
    }
}
