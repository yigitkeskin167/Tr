using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

// Oyun başladığında mobil joystick ve butonları otomatik üretir.
// PC'de de ekranda görünür; test etmek için Editor'de de kullanılabilir.
public class MobileControlsSetup : MonoBehaviour
{
    public PlayerController player;
    public bool showInEditor = true;

    void Start()
    {
        if (!Application.isMobilePlatform && !showInEditor) return;
        if (player == null) player = FindObjectOfType<PlayerController>();
        if (player == null) return;

        if (FindObjectOfType<EventSystem>() == null)
            new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

        Canvas canvas = FindObjectOfType<Canvas>();
        if (canvas == null)
        {
            GameObject canvasObject = new GameObject("Mobile Controls Canvas",
                typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.matchWidthOrHeight = 0.5f;
        }

        // Sol altta joystick.
        GameObject stick = MakeUI("Move Joystick", canvas.transform,
            new Vector2(0, 0), new Vector2(210, 210), new Vector2(0.16f, 0.18f),
            new Color(1, 1, 1, 0.22f));
        GameObject handle = MakeUI("Joystick Handle", stick.transform,
            new Vector2(0, 0), new Vector2(90, 90), new Vector2(0.5f, 0.5f),
            new Color(1, 1, 1, 0.7f));
        MobileJoystick joystick = stick.AddComponent<MobileJoystick>();
        joystick.background = stick.GetComponent<RectTransform>();
        joystick.handle = handle.GetComponent<RectTransform>();
        joystick.targetPlayer = player;

        // Sağ altta pas, şut ve sprint butonları.
        GameObject pass = MakeButton("PASS", canvas.transform, new Vector2(0.82f, 0.16f),
            new Vector2(135, 100), new Color(0.12f, 0.42f, 0.95f, 0.8f));
        pass.GetComponent<Button>().onClick.AddListener(player.MobilePass);

        GameObject shoot = MakeButton("SHOOT", canvas.transform, new Vector2(0.92f, 0.23f),
            new Vector2(160, 125), new Color(0.9f, 0.15f, 0.12f, 0.88f));
        MobileHoldButton shootHold = shoot.AddComponent<MobileHoldButton>();
        shootHold.player = player;
        shootHold.actionType = MobileHoldButton.ActionType.Shoot;

        GameObject sprint = MakeButton("SPRINT", canvas.transform, new Vector2(0.82f, 0.33f),
            new Vector2(135, 90), new Color(0.12f, 0.7f, 0.35f, 0.8f));
        MobileHoldButton sprintHold = sprint.AddComponent<MobileHoldButton>();
        sprintHold.player = player;
        sprintHold.actionType = MobileHoldButton.ActionType.Sprint;
    }

    GameObject MakeButton(string label, Transform parent, Vector2 anchor,
        Vector2 size, Color color)
    {
        GameObject go = MakeUI(label + " Button", parent, Vector2.zero, size, anchor, color);
        Button button = go.AddComponent<Button>();
        button.targetGraphic = go.GetComponent<Image>();
        Text text = new GameObject("Label", typeof(RectTransform), typeof(Text)).GetComponent<Text>();
        text.transform.SetParent(go.transform, false);
        RectTransform rt = text.rectTransform;
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        text.text = label;
        text.alignment = TextAnchor.MiddleCenter;
        text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        text.fontSize = 24; text.fontStyle = FontStyle.Bold;
        text.color = Color.white;
        return go;
    }

    GameObject MakeUI(string name, Transform parent, Vector2 anchoredPosition,
        Vector2 size, Vector2 anchor, Color color)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchor; rt.anchorMax = anchor;
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = anchoredPosition;
        rt.sizeDelta = size;
        Image image = go.GetComponent<Image>();
        image.color = color;
        return go;
    }
}
