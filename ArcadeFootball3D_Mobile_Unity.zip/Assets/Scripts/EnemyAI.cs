using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class EnemyAI : MonoBehaviour
{
    public enum State { ChaseBall, Dribble, Shoot }
    public State CurrentState { get; private set; }
    public BallController ball;
    public Transform targetGoal;
    public float moveSpeed = 5.4f;
    public float controlDistance = 1.7f;
    public float shootDistance = 13f;
    public float shotPower = 14f;

    Rigidbody body;
    float nextShootTime;

    void Awake()
    {
        body = GetComponent<Rigidbody>();
        body.constraints |= RigidbodyConstraints.FreezeRotationX |
                            RigidbodyConstraints.FreezeRotationZ;
        if (ball == null) ball = FindObjectOfType<BallController>();
    }

    void FixedUpdate()
    {
        if (ball == null || targetGoal == null) return;

        if (ball.Owner != gameObject)
        {
            CurrentState = State.ChaseBall;
            if (ball.Owner == null &&
                Vector3.Distance(transform.position, ball.transform.position) <= controlDistance)
            {
                if (ball.TryTake(gameObject)) CurrentState = State.Dribble;
            }
            else MoveToward(ball.transform.position);
            return;
        }

        if (Vector3.Distance(transform.position, targetGoal.position) <= shootDistance &&
            Time.time >= nextShootTime)
        {
            CurrentState = State.Shoot;
            Vector3 aim = targetGoal.position - ball.transform.position;
            aim.y = 0.12f;
            ball.Kick(aim.normalized, shotPower);
            nextShootTime = Time.time + 1.1f;
        }
        else
        {
            CurrentState = State.Dribble;
            MoveToward(targetGoal.position);
        }
    }

    void MoveToward(Vector3 target)
    {
        Vector3 direction = target - transform.position;
        direction.y = 0f;
        if (direction.sqrMagnitude < 0.02f) return;
        direction.Normalize();
        Vector3 v = direction * moveSpeed;
        body.velocity = new Vector3(v.x, body.velocity.y, v.z);
        body.MoveRotation(Quaternion.Slerp(body.rotation,
            Quaternion.LookRotation(direction), 8f * Time.fixedDeltaTime));
    }
}
