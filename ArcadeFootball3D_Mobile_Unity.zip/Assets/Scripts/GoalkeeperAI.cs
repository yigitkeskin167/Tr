using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class GoalkeeperAI : MonoBehaviour
{
    public BallController ball;
    public float lineZ = 43f;
    public float minX = -3.2f;
    public float maxX = 3.2f;
    public float followSpeed = 6f;
    public float interceptDistance = 1.25f;

    Rigidbody body;

    void Awake()
    {
        body = GetComponent<Rigidbody>();
        body.isKinematic = true;
        body.useGravity = false;
        body.constraints = RigidbodyConstraints.FreezePositionY |
                           RigidbodyConstraints.FreezeRotation;
        if (ball == null) ball = FindObjectOfType<BallController>();
    }

    void FixedUpdate()
    {
        if (ball == null) return;
        float targetX = Mathf.Clamp(ball.transform.position.x, minX, maxX);
        Vector3 target = new Vector3(targetX, body.position.y, lineZ);
        body.MovePosition(Vector3.MoveTowards(body.position, target,
            followSpeed * Time.fixedDeltaTime));

        if (ball.Owner == null &&
            Vector3.Distance(transform.position, ball.transform.position) <= interceptDistance)
            ball.TryTake(gameObject);
    }
}
