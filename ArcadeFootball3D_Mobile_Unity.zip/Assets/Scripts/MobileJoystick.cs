using UnityEngine;
using UnityEngine.EventSystems;

// UI üzerindeki joystick alanını sürükleyerek hareket vektörü üretir.
public class MobileJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    public RectTransform background;
    public RectTransform handle;
    public float handleRange = 70f;
    public PlayerController targetPlayer;

    void Awake()
    {
        if (background == null) background = transform as RectTransform;
    }

    public void OnPointerDown(PointerEventData eventData) { OnDrag(eventData); }

    public void OnDrag(PointerEventData eventData)
    {
        if (background == null || handle == null) return;

        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(
            background, eventData.position, eventData.pressEventCamera, out Vector2 local))
        {
            Vector2 half = background.rect.size * 0.5f;
            Vector2 normalized = new Vector2(
                half.x > 0 ? local.x / half.x : 0,
                half.y > 0 ? local.y / half.y : 0);
            normalized = Vector2.ClampMagnitude(normalized, 1f);
            handle.anchoredPosition = normalized * handleRange;

            if (targetPlayer != null)
                targetPlayer.SetMoveInput(normalized);
        }
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if (handle != null) handle.anchoredPosition = Vector2.zero;
        if (targetPlayer != null) targetPlayer.SetMoveInput(Vector2.zero);
    }
}
