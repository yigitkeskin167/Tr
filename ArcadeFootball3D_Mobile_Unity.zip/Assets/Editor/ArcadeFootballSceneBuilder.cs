#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

public static class ArcadeFootballSceneBuilder
{
    [MenuItem("Arcade Football/Create Mobile Prototype Scene")]
    public static void CreateScene()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        Material green = Mat("Pitch Green", new Color(0.12f, 0.48f, 0.18f));
        Material white = Mat("Line White", Color.white);
        Material blue = Mat("Blue Team", new Color(0.08f, 0.32f, 1f));
        Material red = Mat("Red Team", new Color(0.9f, 0.08f, 0.08f));
        Material black = Mat("Ball", new Color(0.06f, 0.06f, 0.06f));
        Material goalMat = Mat("Goal White", new Color(0.9f, 0.9f, 0.9f));

        Cube("Pitch", new Vector3(0, -0.25f, 0), new Vector3(22, 0.5f, 90), green);
        Cube("Halfway Line", new Vector3(0, 0.02f, 0), new Vector3(22, 0.025f, 0.12f), white);
        Cube("Touchline Left", new Vector3(-10.9f, 0.02f, 0), new Vector3(0.12f, 0.025f, 90), white);
        Cube("Touchline Right", new Vector3(10.9f, 0.02f, 0), new Vector3(0.12f, 0.025f, 90), white);
        Cube("Endline North", new Vector3(0, 0.02f, 44.9f), new Vector3(22, 0.025f, 0.12f), white);
        Cube("Endline South", new Vector3(0, 0.02f, -44.9f), new Vector3(22, 0.025f, 0.12f), white);

        GameObject player = Capsule("Blue Player", new Vector3(0, 1, -8), blue, "Player");
        Rigidbody prb = player.AddComponent<Rigidbody>();
        prb.mass = 70; prb.drag = 3;
        prb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
        PlayerController pc = player.AddComponent<PlayerController>();

        GameObject ballObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        ballObj.name = "Ball"; EnsureTag("Ball"); ballObj.tag = "Ball";
        ballObj.transform.position = new Vector3(0, 0.45f, -6.5f);
        ballObj.transform.localScale = Vector3.one * 0.85f;
        ballObj.GetComponent<Renderer>().sharedMaterial = black;
        Rigidbody brb = ballObj.AddComponent<Rigidbody>(); brb.mass = 0.43f; brb.drag = 0.18f;
        BallController ball = ballObj.AddComponent<BallController>(); pc.ball = ball;

        GameObject enemy = Capsule("Red Enemy", new Vector3(0, 1, 12), red, "Enemy");
        Rigidbody erb = enemy.AddComponent<Rigidbody>(); erb.mass = 70; erb.drag = 3;
        erb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
        EnemyAI ai = enemy.AddComponent<EnemyAI>(); ai.ball = ball;
        GameObject blueTarget = new GameObject("Blue Goal Target"); blueTarget.transform.position = new Vector3(0, 0, -45);
        ai.targetGoal = blueTarget.transform;

        CreateGoal("Blue Goal", -45f, goalMat, false);
        CreateGoal("Red Goal", 45f, goalMat, true);

        GameObject keeper1 = Capsule("Blue Goalkeeper", new Vector3(0, 1, -43), blue, "Goalkeeper");
        AddKinematicBody(keeper1);
        GoalkeeperAI gk1 = keeper1.AddComponent<GoalkeeperAI>(); gk1.ball = ball; gk1.lineZ = -43;
        GameObject keeper2 = Capsule("Red Goalkeeper", new Vector3(0, 1, 43), red, "Goalkeeper");
        AddKinematicBody(keeper2);
        GoalkeeperAI gk2 = keeper2.AddComponent<GoalkeeperAI>(); gk2.ball = ball; gk2.lineZ = 43;

        GameObject camObj = new GameObject("Main Camera"); camObj.tag = "MainCamera";
        camObj.AddComponent<Camera>().fieldOfView = 60;
        camObj.AddComponent<AudioListener>();
        FollowCamera follow = camObj.AddComponent<FollowCamera>();
        follow.target = player.transform; follow.offset = new Vector3(0, 11, -13);

        GameObject lightObj = new GameObject("Directional Light");
        Light light = lightObj.AddComponent<Light>(); light.type = LightType.Directional;
        light.intensity = 1.25f; lightObj.transform.rotation = Quaternion.Euler(50, -30, 0);

        GameObject canvasObj = new GameObject("Game UI", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas canvas = canvasObj.GetComponent<Canvas>(); canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvasObj.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        Text score = MakeText(canvasObj.transform, "Score", "MAVİ  0 - 0  KIRMIZI", new Vector2(0.5f, 0.94f), new Vector2(700, 70), 32);
        Text msg = MakeText(canvasObj.transform, "Message", "MAÇ BAŞLADI", new Vector2(0.5f, 0.86f), new Vector2(800, 55), 24);

        GameObject gmObj = new GameObject("GameManager");
        GameManager gm = gmObj.AddComponent<GameManager>();
        gm.ball = ball; gm.scoreText = score; gm.messageText = msg;
        gm.kickoffPoint = Empty("Kickoff Point", new Vector3(0, 0.45f, 0));
        gm.playerSpawn = Empty("Player Spawn", new Vector3(0, 1, -8));
        gm.enemySpawn = Empty("Enemy Spawn", new Vector3(0, 1, 12));

        // Oyun açılır açılmaz dokunmatik joystick ve aksiyon butonlarını üret.
        GameObject controls = new GameObject("Mobile Controls Setup");
        MobileControlsSetup mobile = controls.AddComponent<MobileControlsSetup>();
        mobile.player = pc;
        mobile.showInEditor = true;

        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene, "Assets/ArcadeFootballMobile.unity");
        EditorUtility.DisplayDialog("Arcade Football Mobile",
            "Mobil prototip sahnesi oluşturuldu.\nPlay'e bas. Android/iOS için Build Settings'ten platform seç.",
            "Tamam");
    }

    static Transform Empty(string name, Vector3 position)
    {
        GameObject go = new GameObject(name); go.transform.position = position; return go.transform;
    }

    static void CreateGoal(string name, float z, Material mat, bool playerTeamScores)
    {
        float dir = z > 0 ? -1f : 1f;
        Cube(name + " Left Post", new Vector3(-3.5f, 1.25f, z), new Vector3(0.18f, 2.5f, 0.18f), mat);
        Cube(name + " Right Post", new Vector3(3.5f, 1.25f, z), new Vector3(0.18f, 2.5f, 0.18f), mat);
        Cube(name + " Crossbar", new Vector3(0, 2.5f, z), new Vector3(7.1f, 0.18f, 0.18f), mat);
        Cube(name + " Net Back", new Vector3(0, 1.2f, z + dir * 2f), new Vector3(7f, 2.4f, 0.08f), mat);
        GameObject trigger = new GameObject(name + " Goal Trigger");
        trigger.transform.position = new Vector3(0, 1.2f, z + dir * 0.9f);
        BoxCollider col = trigger.AddComponent<BoxCollider>(); col.isTrigger = true;
        col.size = new Vector3(6.8f, 2.3f, 2.4f);
        GoalTrigger goal = trigger.AddComponent<GoalTrigger>(); goal.playerTeamScores = playerTeamScores;
    }

    static void AddKinematicBody(GameObject obj)
    {
        Rigidbody rb = obj.AddComponent<Rigidbody>(); rb.isKinematic = true; rb.useGravity = false;
    }

    static GameObject Cube(string name, Vector3 pos, Vector3 scale, Material mat)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name; go.transform.position = pos; go.transform.localScale = scale;
        go.GetComponent<Renderer>().sharedMaterial = mat; return go;
    }

    static GameObject Capsule(string name, Vector3 pos, Material mat, string tag)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        go.name = name; go.transform.position = pos; go.GetComponent<Renderer>().sharedMaterial = mat;
        EnsureTag(tag); go.tag = tag; return go;
    }

    static Material Mat(string name, Color color)
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null) shader = Shader.Find("Standard");
        Material mat = new Material(shader); mat.name = name; mat.color = color; return mat;
    }

    static Text MakeText(Transform parent, string name, string content, Vector2 anchor, Vector2 size, int fontSize)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Text));
        go.transform.SetParent(parent, false);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchor; rt.anchorMax = anchor; rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = Vector2.zero; rt.sizeDelta = size;
        Text t = go.GetComponent<Text>(); t.text = content;
        t.font = Resources.GetBuiltinResource<Font>("Arial.ttf"); t.fontSize = fontSize;
        t.alignment = TextAnchor.MiddleCenter; t.color = Color.white; return t;
    }

    static void EnsureTag(string tag)
    {
        if (System.Array.IndexOf(UnityEditorInternal.InternalEditorUtility.tags, tag) >= 0) return;
        UnityEditorInternal.InternalEditorUtility.AddTag(tag);
    }
}
#endif
