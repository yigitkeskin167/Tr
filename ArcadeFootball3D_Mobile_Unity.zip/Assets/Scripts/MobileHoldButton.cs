using UnityEngine;
using UnityEngine.EventSystems;

// Basılı tutulabilen mobil buton. Şut gücü biriktirme ve koşu için kullanılır.
public class MobileHoldButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public PlayerController player;
    public enum ActionType { Shoot, Sprint }
    public ActionType actionType;

    public void OnPointerDown(PointerEventData eventData)
    {
        if (player == null) return;
        if (actionType == ActionType.Shoot) player.MobileShootDown();
        else player.SetSprint(true);
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if (player == null) return;
        if (actionType == ActionType.Shoot) player.MobileShootUp();
        else player.SetSprint(false);
    }

    public void OnDisable()
    {
        if (player == null) return;
        if (actionType == ActionType.Shoot) player.MobileShootUp();
        else player.SetSprint(false);
    }
}
